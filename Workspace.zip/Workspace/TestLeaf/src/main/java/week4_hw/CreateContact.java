package week4_hw;

import org.testng.annotations.Test;

public class CreateContact extends OpenTapsWrapper{

	@Test(description="Create Lead Test method", groups={"Smoke","Sanity"})
	public void createContact()
	{
		linkClickByLinkText("Create Contact");
		sleepForSec(1000);
		inputTextByID("firstNameField", "Caramel");
		inputTextByID("lastNameField", "Gold");
		inputTextByID("createContactForm_primaryEmail", "Caramel_Gold@test.leaf.com");
		inputTextByID("createContactForm_primaryPhoneNumber", "147258369");
		selectById("createContactForm_generalCountryGeoId", "India");
		linkClickByXpath("//input[@value='Create Contact']");
		sleepForSec(2000);
		//Get the contact id
		String idString = driver.findElementById("viewContact_fullName_sp").getText();
		int startPos =  idString.indexOf("(");
		int endPos =  idString.indexOf(")");
		contactId = idString.substring(startPos+1, endPos);
		System.out.println("Newly Created ContactID is: " + contactId);
	}
}

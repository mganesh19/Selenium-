package week4_hw;

import org.testng.annotations.Test;

public class EditContact extends OpenTapsWrapper{

	@Test(description="Edit Contact Test method", groups="Sanity", dependsOnGroups="Smoke")
	public void editContact()
	{
		linkClickByXpath("//a[text()='Contacts']");
		sleepForSec(1000);
		linkClickByXpath("//a[text()='Find Contacts']");
		sleepForSec(1000);
		inputTextByXPath("(//input[@name='firstName'])[3]", "Caramel");
		linkClickByXpath("//button[contains(text(),'Find Contacts')]");
		linkClickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a");
		verifyBrowserTitle("View Contact");
		linkClickByLinkText("Edit");
		selectById("addMarketingCampaignForm_marketingCampaignId", "Pay Per Click Advertising");
		linkClickByXpath("(//input[@class='smallSubmit' and @value='Add'])[1]");
		sleepForSec(1000);
		verifyTextByXpath("(//table[@class='crmsfaListTable'])//tr[2]//td//a", "Pay Per Click Advertising");
	}
}

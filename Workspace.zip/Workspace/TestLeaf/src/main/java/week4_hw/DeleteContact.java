package week4_hw;

import org.testng.annotations.Test;

public class DeleteContact extends OpenTapsWrapper{
	
	@Test(description="Delete Contact Test method", groups="Sanity", dependsOnGroups="Smoke")
	public void deleteContact()
	{
		linkClickByLinkText("Contacts");
		linkClickByLinkText("Find Contacts");
		linkClickByLinkText("Phone");
		inputTextByName("phoneNumber","147258369");
		linkClickByXpath("//button[contains(text(),'Find Contacts')]");
		sleepForSec(3000);
		String Contactid = driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a").getText();
		System.out.println("Contact ID taken for Delete: " + Contactid);
		linkClickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a");
		sleepForSec(8000);
		linkClickByClass("subMenuButtonDangerous");
		alertHandle("alert", "");
		sleepForSec(5000);
		linkClickByLinkText("Find Contacts");
		inputTextByXPath("(//input[@name='id'])", Contactid);
		linkClickByXpath("//button[contains(text(),'Find Contacts')]");
		verifyTextByXpath("//div[text()='No records to display']", "No rsecords to display");
	}
}

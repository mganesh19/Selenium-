package week4_hw;

import org.testng.annotations.Test;

public class DeleteLead extends OpenTapsWrapper {

	@Test(description="Delete Lead Test method", groups="Sanity", dependsOnGroups="Smoke")
	public void deleteLead()
	{
		//linkClickByXpath("//*[@id='label']");
		linkClickByLinkText("Leads");
		linkClickByLinkText("Find Leads");
		linkClickByLinkText("Phone");
		inputTextByName("phoneNumber","8973995059");
		linkClickByXpath("//button[contains(text(),'Find Leads')]");
		sleepForSec(3000);
		String Leadid = driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a").getText();
		System.out.println("Lead ID taken for Delete: " + Leadid);
		linkClickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a");
		sleepForSec(8000);
		linkClickByClass("subMenuButtonDangerous");
		sleepForSec(5000);
		
		/*linkClickByLinkText("Phone");
		inputTextByName("phoneNumber","8973995058");
		linkClickByXpath("//button[contains(text(),'Find Leads')]");*/

		linkClickByLinkText("Find Leads");
		inputTextByXPath("(//input[@name='id'])", Leadid);
		linkClickByXpath("//button[contains(text(),'Find Leads')]");
		
		verifyTextByXpath("//div[text()='No records to display']", "No records to display");
	}
}

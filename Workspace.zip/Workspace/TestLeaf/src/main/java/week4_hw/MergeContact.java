package week4_hw;

import org.testng.annotations.Test;

public class MergeContact extends OpenTapsWrapper{

	@Test(description="Merge Contact Test method", groups="Sanity", dependsOnGroups="Smoke")
	public void mergeContact()
	{
		linkClickByLinkText("Contacts");
		linkClickByLinkText("Merge Contacts");
		String currentWind = getCurrentWindowHandle();
		linkClickByXpath("//span[contains(text(), 'From Contact')]/following::a");
		sleepForSec(5000);
		switchToLastWindow();
		inputTextByName("id", contactId);
		linkClickByXpath("//button[@class='x-btn-text' and text()='Find Contacts']");
		linkClickByLinkText(contactId);
		System.out.println("Contact ID to be searched: " + contactId);
		sleepForSec(2000);
		switchToSpecificWindow(currentWind);
		linkClickByXpath("//span[contains(text(), 'To Contact')]/following::a");
		switchToLastWindow();
		inputTextByName("id", "10091");
		linkClickByXpath("//button[@class='x-btn-text' and text()='Find Contacts']");
		linkClickByLinkText("10091");
		switchToSpecificWindow(currentWind);
		linkClickByClass("buttonDangerous");
		sleepForSec(1000);
		alertHandle("alert","");
		linkClickByLinkText("Find Contacts");
		inputTextByName("id", contactId);
		linkClickByXpath("//button[contains(text(),'Find Contacts')]");
		verifyTextByClassName("x-paging-info", "No records to display");
	}
}

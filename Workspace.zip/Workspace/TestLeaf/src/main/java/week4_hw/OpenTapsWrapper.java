package week4_hw;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

//Wrapper Class to have all Wrapper Methods
public class OpenTapsWrapper {
	//Declaring Global Variable
	RemoteWebDriver driver;
	int snapCounter = 1;
	public static String contactId="";
	public static String leadId = "";
	
	@BeforeSuite(description="Before Test Suite", groups={"Smoke","Sanity"})
	public void fnBeforeSuite()
	{
		System.out.println("I am in Before Suite method");
	}
	
	@BeforeTest(description="Before Test", groups={"Smoke","Sanity"})
	public void fnBeforeTest()
	{
		System.out.println("I am in Before Test method");
	}

	/**
	 * Method Name	: launchBrowser
	 * @param browserName : Which browser to be opened Chrome/Firefox
	 * @param url	: URL to be loaded on the browser
	 */
	@BeforeClass(description="Launch Browser", groups={"Smoke","Sanity"})
	@Parameters({"browser","url"})
	public void launchBrowser(String browserName, String url)
	{
		try
		{
			if(browserName.equalsIgnoreCase("chrome"))
			{
				//Creating driver for chrome browser
				System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
				driver = new ChromeDriver();
				
				sleepForSec(2000);
			}
			else if(browserName.equalsIgnoreCase("firefox"))
			{
				//Creating driver for Firefox browser
				driver = new FirefoxDriver();
			}

			//Implicit Wait
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			//Maximize the window
			driver.manage().window().maximize();

			//launch the URL
			driver.get(url);

			System.out.println(browserName + " Browser is launched with URL: " + url);
		}
		catch(WebDriverException e)
		{
			System.out.println(browserName + " Browser cannot be launched with URL: " + url);
		}
		finally
		{
			//Calling method to take screenshot
			//takeScreenShot();
		}
	}

	/**
	 * Function Name	: takeScreenShot
	 * Description		: To take screenshot of the current webpage
	 */
	public void takeScreenShot()
	{
		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try
		{
			FileUtils.copyFile(screenshotFile, new File("./images/Snap_" + snapCounter + ".jpg"));
			snapCounter++;
		}
		catch (IOException e)
		{
			System.out.println("Screenshot cannot be taken, IOException is thrown" + e.getMessage());
		}
	}
	
	/**
	 * Method Name	:inputTextByID
	 * @param id	:locator value
	 * @param value	:Value to be inputted on the textbox
	 */
	public void inputTextByID(String id, String value)
	{
		try
		{
			driver.findElementById(id).clear();
			driver.findElementById(id).sendKeys(value);
			System.out.println("Textbox is available and inputted with " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Textbox is not available on the page" + id);
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name		:inputTextByClass
	 * @param className	:locator value
	 * @param value		:Value to be inputted on the textbox
	 */
	public void inputTextByClass(String className, String value)
	{
		try
		{
			driver.findElementByClassName(className).clear();
			driver.findElementByClassName(className).sendKeys(value);
			
			System.out.println("Textbox is available and inputted with " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Textbox is not available on the page" +className);
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}
	/**
	 * Method Name		:inputTextByName
	 * @param name	:locator value
	 * @param value		:Value to be inputted on the textbox
	 */
	public void inputTextByName(String name, String value)
	{
		try
		{
			driver.findElementByName(name).clear();
			driver.findElementByName(name).sendKeys(value);
			
			System.out.println("Textbox is available and inputted with " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Textbox is not available on the page" + name);
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}
	/**
	 * Method Name		:inputTextByXPath
	 * @param xpath		:locator value
	 * @param value		:Value to be inputted on the textbox
	 */
	public void inputTextByXPath(String xpath, String value)
	{
		try
		{
			driver.findElementByXPath(xpath).clear();
			driver.findElementByXPath(xpath).sendKeys(value);
			
			System.out.println("Textbox is available and inputted with " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Textbox is not available on the page (Xpath)" + e.getMessage());
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name		:radioselectById
	 * @param id		:locator value
	 * @param value		:Value to be selected on radiogroup
	 */
	public void radioselectById(String id, String value)
	{
		List<WebElement> radioGroup = null;
		String sValue = "";
		try
		{
			radioGroup = driver.findElementsById(id);
			for(int i=0; i<radioGroup.size(); i++)
			{
				sValue = radioGroup.get(i).getAttribute("value");

				if(sValue.equalsIgnoreCase(value))	    	
					radioGroup.get(i).click();
			}
			System.out.println("RadioGroup is located and '" + value + "' is selected");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("RadioGroup is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}
	
	/**
	 * Method Name		:radioselectByName
	 * @param name		:locator value
	 * @param value		:Value to be selected on radiogroup
	 */
	public void radioselectByName(String name, String value)
	{
		List<WebElement> radioGroup = null;
		String sValue = "";
		try
		{
			radioGroup = driver.findElementsByName(name);
			for(int i=0; i<radioGroup.size(); i++)
			{
				sValue = radioGroup.get(i).getAttribute("value");

				if(sValue.equalsIgnoreCase(value))	    	
					radioGroup.get(i).click();
			}
			System.out.println("RadioGroup is located and '" + value + "' is selected");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("RadioGroup is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name			:radioselectByClass
	 * @param className		:locator value
	 * @param value			:Value to be selected on radiogroup
	 */
	public void radioselectByClass(String className, String value)
	{
		List<WebElement> radioGroup = null;
		String sValue = "";
		try
		{
			radioGroup = driver.findElementsByClassName(className);
			for(int i=0; i<radioGroup.size(); i++)
			{
				sValue = radioGroup.get(i).getAttribute("value");

				if(sValue.equalsIgnoreCase(value))	    	
					radioGroup.get(i).click();
			}
			System.out.println("RadioGroup is located and '" + value + "' is selected");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("RadioGroup is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name			:radioselectByXpath
	 * @param xpathExp		:locator value
	 * @param value			:Value to be selected on radiogroup
	 */
	public void radioselectByXpath(String xpathExp, String value)
	{
		List<WebElement> radioGroup = null;
		String sValue = "";
		try
		{
			radioGroup = driver.findElementsByClassName(xpathExp);
			for(int i=0; i<radioGroup.size(); i++)
			{
				sValue = radioGroup.get(i).getAttribute("value");

				if(sValue.equalsIgnoreCase(value))	    	
					radioGroup.get(i).click();
			}
			System.out.println("RadioGroup is located and '" + value + "' is selected");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("RadioGroup is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name		:selectById
	 * @param id		:locator value
	 * @param value		:Value to be selected on Dropdown
	 */
	public void selectById(String id, String value)
	{
		try
		{
			WebElement list = null;

			list = driver.findElementById(id);

			//To create new select class from list
			Select lstSelect = new Select(list);
			//To select the given value
			lstSelect.selectByVisibleText(value);

			System.out.println("Listbox is located and the Selected Value: " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Listbox is not available on the page");
		}
		finally
		{
			//Method to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name		:selectByXpath
	 * @param xpathExp	:locator value
	 * @param value		:Value to be selected on Dropdown
	 */
	public void selectByXpath(String xpathExp, String value)
	{
		try
		{
			WebElement list = null;

			list = driver.findElementByXPath(xpathExp);

			//To create new select class from list
			Select lstSelect = new Select(list);
			//To select the given value
			lstSelect.selectByVisibleText(value);

			System.out.println("Listbox is located and the Selected Value: " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Listbox is not available on the page");
		}
		finally
		{
			//Method to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name		:selectByClass
	 * @param className	:locator value
	 * @param value		:Value to be selected on Dropdown
	 */
	public void selectByClass(String className, String value)
	{
		try
		{
			WebElement list = null;

			list = driver.findElementByClassName(className);

			//To create new select class from list
			Select lstSelect = new Select(list);
			//To select the given value
			lstSelect.selectByVisibleText(value);

			System.out.println("Listbox is located and the Selected Value: " + value);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Listbox is not available on the page");
		}
		finally
		{
			//Method to take screenshot
			takeScreenShot();
		}
	}

	/**
	 * Method Name	:linkClickById
	 * @param id	:locator value
	 */
	public void linkClickById(String id)
	{
		try
		{
			driver.findElementById(id).click();
			//Make driver to sleep
			sleepForSec(3000);

			System.out.println("Element is located and clicked");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}		
	}

	/**
	 * Method Name		:linkClickByClass
	 * @param className	:locator value
	 */
	public void linkClickByClass(String className)
	{
		try
		{
			driver.findElementByClassName(className).click();
			//Make driver to sleep
			sleepForSec(3000);

			System.out.println("Element was located and clicked");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element was not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			//takeScreenShot();
		}		
	}

	/**
	 * Method Name	:linkClickByName
	 * @param name	:locator value
	 */
	public void linkClickByName(String name)
	{
		try
		{
			driver.findElementByName(name).click();
			//Make driver to sleep
			sleepForSec(3000);

			System.out.println("Element was located and clicked");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element was not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}		
	}

	/**
	 * Method Name		:linkClickByXpath
	 * @param xpathExp	:locator value
	 */
	public void linkClickByXpath(String xpathExp)
	{
		try
		{
			driver.findElementByXPath(xpathExp).click();
			//Make driver to sleep
			sleepForSec(3000);

			System.out.println("Element was located and clicked");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element was not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}		
	}

	/**
	 * Method Name		:linkClickByLinkText
	 * @param linkText	:locator value
	 */
	public void linkClickByLinkText(String linkText)
	{
		try
		{
			driver.findElementByLinkText(linkText).click();
			//Make driver to sleep
			sleepForSec(3000);

			System.out.println("Element was located and clicked (by linkClickByLinkText method) " + linkText);
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element was not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			//takeScreenShot();
			System.out.println("linkClickByLinkText method over");
		}		
	}
	
	/**
	 * Method Name		:linkClickByCss
	 * @param cssValue	:locator value
	 */
	public void linkClickByCss(String cssValue)
	{
		try
		{
			driver.findElementByCssSelector(cssValue).click();
			//Make driver to sleep
			sleepForSec(3000);

			System.out.println("Element was located and clicked");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Element was not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}		
	}

	/**
	 * Method Name			:verifyTextById
	 * @param cssValue		:locator value
	 * @param expectedValue :value expected in the WebElement
	 */
	public void verifyTextById(String id, String expectedValue)
	{
		try
		{
			String actualValue = "";

			actualValue = driver.findElementById(id).getText();

			//Compare the actual with expected
			if(actualValue.equalsIgnoreCase(expectedValue))
				System.out.println("WebElement Text is as expected. Actual Value is: " + actualValue);
			else
				System.out.println("WebElement Text is not as expected:'" + expectedValue + "'. Actual Value is: " + actualValue);

			System.out.println("WebElement is located and verified");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("WebElemet is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}			
	}

	/**
	 * Method Name			:verifyTextByClassName
	 * @param className		:locator value
	 * @param expectedValue :value expected in the WebElement
	 */
	public void verifyTextByClassName(String className, String expectedValue)
	{
		try
		{
			String actualValue = "";

			actualValue = driver.findElementByClassName(className).getText();

			//Compare the actual with expected
			if(actualValue.equalsIgnoreCase(expectedValue))
				System.out.println("WebElement Text is as expected. Actual Value is: " + actualValue);
			else
				System.out.println("WebElement Text is not as expected:'" + expectedValue + "'. Actual Value is: " + actualValue);

			System.out.println("WebElement is located and verified");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("WebElemet is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}			
	}

	/**
	 * Method Name			:verifyTextByName
	 * @param name		:locator value
	 * @param expectedValue :value expected in the WebElement
	 */
	public void verifyTextByName(String name, String expectedValue)
	{
		try
		{
			String actualValue = "";

			actualValue = driver.findElementByName(name).getText();

			//Compare the actual with expected
			if(actualValue.equalsIgnoreCase(expectedValue))
				System.out.println("WebElement Text is as expected. Actual Value is: " + actualValue);
			else
				System.out.println("WebElement Text is not as expected:'" + expectedValue + "'. Actual Value is: " + actualValue);

			System.out.println("WebElement is located and verified");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("WebElemet is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}			
	}

	/**
	 * Method Name			:verifyTextByXpath
	 * @param xpathExp		:locator value
	 * @param expectedValue :value expected in the WebElement
	 */
	public void verifyTextByXpath(String xpathExp, String expectedValue)
	{
		try
		{
			String actualValue = "";

			actualValue = driver.findElementByXPath(xpathExp).getText();

			//Compare the actual with expected
			if(actualValue.contains(expectedValue))
				System.out.println("WebElement Text is as expected. Actual Value is: " + actualValue);
			else
				System.out.println("WebElement Text is not as expected:'" + expectedValue + "'. Actual Value is: " + actualValue);

			System.out.println("WebElement is located and verified");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("WebElemet is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}			
	}

	/**
	 * Method Name			:verifyTextByCss
	 * @param cssVal		:locator value
	 * @param expectedValue :value expected in the WebElement
	 */
	public void verifyTextByCss(String cssVal, String expectedValue)
	{
		try
		{
			String actualValue = "";

			actualValue = driver.findElementByCssSelector(cssVal).getText();

			//Compare the actual with expected
			if(actualValue.equalsIgnoreCase(expectedValue))
				System.out.println("WebElement Text is as expected. Actual Value is: " + actualValue);
			else
				System.out.println("WebElement Text is not as expected:'" + expectedValue + "'. Actual Value is: " + actualValue);

			System.out.println("WebElement is located and verified");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("WebElemet is not available on the page");
		}
		finally
		{
			//calling function to take screenshot
			takeScreenShot();
		}			
	}

	/**
	 * Method Name : sleepForSec
	 * @param msecs : Number of seconds to be wait
	 */
	public void sleepForSec(long msecs)
	{
		try
		{
			Thread.sleep(msecs);
		}
		catch (InterruptedException e)
		{
			System.out.println("Exception raised on Thread.Sleep method");
		}
	}

	/**
	 * Method Name: switchToDefaultContent
	 * Method to make driver to switch back to main page
	 */
	public void switchToDefaultContent()
	{
		try
		{
			driver.switchTo().defaultContent();
			System.out.println("Switch to default window");
		}
		catch(WebDriverException e)
		{
			System.out.println("Can't able to switch back to main webpage" + e.getLocalizedMessage());
		}
		finally
		{
			takeScreenShot();
			System.out.println("Switch to default window");
		}
	}

	/**
	 * Method Name: switchToLastWindow
	 * Method to make driver to switch back to main page
	 */
	public void switchToLastWindow()
	{
		try
		{
			//Switching the window
			Set<String> allWindow = driver.getWindowHandles();

			for (String oWnd : allWindow) {
				driver.switchTo().window(oWnd);
			}
		}
		catch(Exception e)
		{
			System.out.println("Switching to last window throws exception");
		}
		finally
		{
			takeScreenShot();
		}
	}

	/**
	 * Method Name: switchToSpecificWindow
	 * Method to make driver to switch back to main page
	 */
	public void switchToSpecificWindow(String windowHandle)
	{
		try
		{
			Set<String> allWindow = driver.getWindowHandles();
			System.out.println("switch to specific window");
			for (String oWnd : allWindow)
			{
				if(oWnd.equals(windowHandle))
				{
					driver.switchTo().window(oWnd);
					break;
				}
			}
			System.out.println("Switched to window : " + windowHandle);
		}
		catch(Exception e)
		{
			System.out.println("Switching to specific window throws exception" + e.getMessage());
		}
		finally
		{
			takeScreenShot();
		}
	}

	/**
	 * Method Name	: getCurrentWindowHandle
	 * @return
	 */
	public String getCurrentWindowHandle()
	{
		String windowHandle = "";
		try
		{
			windowHandle = driver.getWindowHandle();
		}
		catch(Exception e)
		{
			System.out.println("Exception throws while getting WindowHandle of Current Window");
		}
		finally
		{
			takeScreenShot();
		}
		return windowHandle;
	}

	/**
	 * Method Name		:alertHandle
	 * @param alertType	:PROMPT/Alert
	 * @param value		:Value to be inputted in Alert box
	 */
	public void alertHandle(String alertType, String value)
	{
		try
		{
			System.out.println("Enter into alert handle method");
			//Swtiching to alert
			Alert alert_box = driver.switchTo().alert();

			if(alertType.equalsIgnoreCase("PROMPT"))
			{
				//Inputing the prompt
				alert_box.sendKeys(value);
			}

			//Clicking OK button on prompt
			alert_box.accept();

			System.out.println("Alert is handled");
		}
		catch(UnhandledAlertException e)
		{
			System.out.println("There is no alert to handle" + e.getLocalizedMessage());
		}
		catch(Exception e)
		{
			System.out.println("Exception in handling alert" + e.getLocalizedMessage());
		}
		finally
		{
			//calling method to take screenshot
			takeScreenShot();
		}
	}
	
	@AfterClass(description="Close the Browser", groups={"Smoke","Sanity"})
	public void closeBrowser()
	{
		try
		{
			driver.close();
			System.out.println("Browser closed successfully");
		}
		catch(Exception e)
		{
			System.out.println("Browser cant be closed, exception throws");
		}
	}
	
	public void verifyBrowserTitle(String expectedTitle)
	{
		String actualTitle = "";
		try
		{
			actualTitle = driver.getTitle();
			if(actualTitle.contains(expectedTitle))
				System.out.println("Browser title is as expected. Actual Title is: " + actualTitle);
			else
			{
				System.out.println("Browser title was not as expected");
				System.out.println("Expected Title is: " + expectedTitle);
				System.out.println("Actual Title is: " + actualTitle);
			}
		}
		catch(Exception e)
		{
			System.out.println("Cant able to get the browser title");
		}
		finally
		{
			takeScreenShot();
		}
	}
	
	@BeforeMethod(description="Login OpenTaps application", groups={"Smoke","Sanity"})
	public void loginOpenTaps()
	{
		sleepForSec(3000);
		if(driver.findElementsById("username").size() > 0)
		{
			inputTextByID("username", "DemoSalesManager");
			inputTextByName("PASSWORD", "crmsfa");
			linkClickByClass("decorativeSubmit");
			
			linkClickByXpath("//*[@id='label']/a");
		}
		else
			System.out.println("Login is skipped because already login");
	}
}
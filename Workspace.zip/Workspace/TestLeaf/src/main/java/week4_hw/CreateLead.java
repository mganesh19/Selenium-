package week4_hw;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateLead extends OpenTapsWrapper {

	@Test(description="Create Lead Test method", dataProvider="CreateLeadData", groups={"Smoke","Sanity"})
	public void createLead(String uName, String pwd, String compName, String fName, String lName, String phoneNo)
	{	
		System.out.println("Create Lead @Test Method");

		linkClickByLinkText("Create Lead");

		//inputTextByID( "createLeadForm_companyName","xyz");
		//inputTextByID( "createLeadForm_firstName", "Caramel_Gold");
		//inputTextByID( "createLeadForm_lastName","Rajaram");
		inputTextByID( "createLeadForm_companyName",compName);
		inputTextByID( "createLeadForm_firstName", fName);
		inputTextByID( "createLeadForm_lastName", lName);
		selectById("createLeadForm_dataSourceId", "Employee");
		selectById("createLeadForm_marketingCampaignId", "Automobile");
		inputTextByID("createLeadForm_primaryEmail","Caramel_Gold@xyz.com");
		inputTextByID("createLeadForm_primaryPhoneNumber", phoneNo);
		linkClickByName("submitButton");

		leadId = driver.findElementById("viewLead_companyName_sp").getText();
		System.out.print("Lead Id: ");
		leadId = leadId.substring(leadId.indexOf("(")+1, leadId.indexOf(")"));
		System.out.println(leadId);
	}

	@DataProvider(name="CreateLeadData")
	public Object[][] getCreateLeadData()
	{
		Object[][] createLeadArray = new Object[2][6];

		createLeadArray[0][0] = "DemoSalesManager";
		createLeadArray[0][1] = "crmsfa";
		createLeadArray[0][2] = "xyz1";
		createLeadArray[0][3] = "Caramel_Gold";
		createLeadArray[0][4] = "Rajaram1";
		createLeadArray[0][5] = "8973995058";

		createLeadArray[1][0] = "DemoSalesManager";
		createLeadArray[1][1] = "crmsfa";
		createLeadArray[1][2] = "xyz2";
		createLeadArray[1][3] = "Caramel_Gold";
		createLeadArray[1][4] = "Rajaram2";
		createLeadArray[1][5] = "8973995059";

		return createLeadArray;
	}
}

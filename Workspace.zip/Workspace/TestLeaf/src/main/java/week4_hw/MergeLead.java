package week4_hw;

import org.testng.annotations.Test;

public class MergeLead extends OpenTapsWrapper {

	@Test(description="Merge Lead Test method", groups="Sanity", dependsOnGroups="Smoke")
	//@Test(description="Merge Lead Test method", groups="Smoke")
	public void mergeLead()
	{
		//linkClickByXpath("//*[@id='label']/a");
		linkClickByLinkText("Leads");
		linkClickByLinkText("Merge Leads");
		String currentWind = getCurrentWindowHandle();
		linkClickByXpath("//span[contains(text(), 'From Lead')]/following::a");
		sleepForSec(5000);
		switchToLastWindow();
		System.out.println("Lead ID to be searched" + leadId);
		inputTextByName("id", leadId);
		linkClickByClass("x-btn-text");
		linkClickByLinkText(leadId);
		sleepForSec(2000);
		switchToSpecificWindow(currentWind);
		linkClickByXpath("//span[contains(text(), 'To Lead')]/following::a");
		switchToLastWindow();
		inputTextByName("id", "10123");
		linkClickByClass("x-btn-text");
		linkClickByLinkText("10123");
		switchToSpecificWindow(currentWind);
		linkClickByClass("buttonDangerous");
		sleepForSec(1000);
		System.out.println("alert main");
		alertHandle("alert","");
		linkClickByLinkText("Find Leads");
		inputTextByName("id", leadId);
		linkClickByXpath("//button[contains(text(),'Find Leads')]");
		verifyTextByClassName("x-paging-info", "No records to display");
	}
}

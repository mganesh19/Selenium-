package week4_hw;

import org.testng.annotations.Test;

public class EditLead extends OpenTapsWrapper {
	
	@Test(description="Edit Lead Test method", groups="Sanity", dependsOnGroups="Smoke")
	public void editLead()
	{
		//linkClickByXpath("//*[@id='button']/a/img");
		linkClickByLinkText("Leads");
		linkClickByLinkText("Find Leads");
		inputTextByXPath("(//input[@name='firstName'])[3]", "Caramel_Gold");
		linkClickByXpath("//button[contains(text(),'Find Leads')]");
		linkClickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a");
		verifyBrowserTitle("View Lead");
		linkClickByLinkText("Edit");
		selectById("addDataSourceForm_dataSourceId","Existing Customer");
		linkClickByXpath("(//input[@class='smallSubmit' and @value='Add'])[1]");
		selectById("addMarketingCampaignForm_marketingCampaignId", "Pay Per Click Advertising");
		linkClickByXpath("(//input[@class='smallSubmit' and @value = 'Add'])[2]");
		verifyTextById("listDataSources_dataSourceId_o_0_sp", "Existing Customer");
		verifyTextByXpath("(//table[@class='crmsfaListTable'])[2]//tr[2]//td//a", "Pay Per Click Advertising");
	}
}

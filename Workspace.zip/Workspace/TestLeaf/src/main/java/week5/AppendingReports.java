package week5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class AppendingReports {

	@Test
	public void appendReports() throws IOException {

		int rowCount = 0;
		String status = "passed", filename = "./test/report.xlsx";

		try {

			FileInputStream fis = new FileInputStream(new File("./test/report.xlsx"));
			

			XSSFWorkbook wBook = new XSSFWorkbook(fis);

			XSSFSheet sheet = wBook.getSheetAt(0);

			rowCount = sheet.getLastRowNum();
			System.out.println(rowCount);
			fis.close();

			FileOutputStream fos = new FileOutputStream(new File("./test/report.xlsx"));
			XSSFRow rowHeader = sheet.createRow(rowCount + 1); // create cell -
																// 1
			XSSFCell cell = rowHeader.createCell(0); // Give cell name
			cell.setCellValue("Login to Opentaps- newly added"); // create cell - 2 XSSFCell
			XSSFCell cell1 = rowHeader.createCell(1); // Give cell name
			cell1.setCellValue(status);
			
				wBook.write(fos);
			 
			fos.close();

		}

		catch (IOException e) {

			e.printStackTrace();
			status = "failed";
		}

		finally {

			System.out.println("successfully created");		}
	}
}

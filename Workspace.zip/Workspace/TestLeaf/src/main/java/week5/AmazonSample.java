package week5;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class AmazonSample {
	@Test
	public void f() {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		try {

			FileInputStream fis = new FileInputStream(new File("./test/Amazonsearch.xlsx"));

			XSSFWorkbook wBook = new XSSFWorkbook(fis);

			XSSFSheet sheet = wBook.getSheetAt(0);

			int rowCount = sheet.getLastRowNum();
			System.out.println(rowCount);
			ChromeDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://www.amazon.in");
		
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			for (int i = 1; i <= rowCount; i++) {

				XSSFRow row = sheet.getRow(i);
				XSSFCell cell = row.getCell(0);
				XSSFCell cell1 = row.getCell(1);
                 String value = cell1.getRawValue();
			
				System.out.println(cell.getStringCellValue() + "::" +value);

				Thread.sleep(5000);
				driver.findElementById("twotabsearchtextbox").clear();
				driver.findElementById("twotabsearchtextbox").sendKeys(row.getCell(0).getStringCellValue());
				driver.findElementByXPath("//*[@id='nav-search']/form/div[2]/div/input").click();
				
				
				Thread.sleep(5000);
				driver.findElementByXPath("(//a[@class='a-link-normal s-access-detail-page  a-text-normal'])["+value+"]").click();
				Thread.sleep(10000);
			}
			driver.close();
		}

		catch (Exception e) {
		e.printStackTrace();
		}
	}
}

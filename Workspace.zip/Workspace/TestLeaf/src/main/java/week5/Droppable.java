package week5;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Droppable {
	@Test
	public void f() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.get("http://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.switchTo().frame(driver.findElementByClassName("demo-frame"));
		
		
		WebElement drag = driver.findElementByXPath("//*[@id='draggable']");
		WebElement drop = driver.findElementByXPath("//*[@id='droppable']");

		Actions builderActions = new Actions(driver);

		builderActions.dragAndDrop(drag, drop).build().perform();

		// driver.close();
	}

}
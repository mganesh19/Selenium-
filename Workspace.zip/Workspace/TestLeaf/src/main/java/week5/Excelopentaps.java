package week5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Excelopentaps {
	@Test
	public void f() throws IOException {

		String status = "passed";

		try {

			FileInputStream fis = new FileInputStream(new File("./test/Login.xlsx"));

			XSSFWorkbook wBook = new XSSFWorkbook(fis);

			XSSFSheet sheet = wBook.getSheetAt(0);

			int rowCount = sheet.getLastRowNum();

			for (int i = 1; i <= rowCount; i++) {

				FirefoxDriver driver = new FirefoxDriver();

				// Go to row
				XSSFRow row = sheet.getRow(i);

				// Go to cell
				XSSFCell cell = row.getCell(0);

				// Go to cell and read
				System.out.println("user name :: " + row.getCell(0).getStringCellValue());
				System.out.println("password :: " + row.getCell(1).getStringCellValue());

				driver.get("http://demo1.opentaps.org/opentaps/control/main");

				// Maximise the Browser

				driver.manage().window().maximize();

				// Set the timeout

				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

				driver.findElementById("username").sendKeys(row.getCell(0).getStringCellValue());
				driver.findElementByName("PASSWORD").sendKeys(row.getCell(1).getStringCellValue());
				driver.findElementByXPath("//*[@id='login']/p[3]/input").click();

				driver.findElementByXPath("//*[@id='logout']/input").click();
				// driver.findElementsByClassName("decorativeSubmit").click();
				Thread.sleep(10000);

				driver.close();

				fis.close();
				status = "pass";
				System.out.println(status);
				// driver.quit();
				Thread.sleep(10000);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status = "fail";
		}

		finally {

			// write xlsx

			FileOutputStream fos = new FileOutputStream(new File("./test/report.xlsx"));
			// Create work book
			XSSFWorkbook wBook = new XSSFWorkbook();
			// Create sheet
			XSSFSheet sheet = wBook.createSheet("Report");
			// Create row
			XSSFRow rowHeader = sheet.createRow(0);
			// create cell - 1
			XSSFCell cell = rowHeader.createCell(0);
			// Give cell name
			cell.setCellValue("Login to Opentaps");

			// create cell - 2
			XSSFCell cell1 = rowHeader.createCell(1);
			// Give cell name
			cell1.setCellValue(status);
			// Write is must , unless it doesn't write the data in your excel
			// sheet
			wBook.write(fos);
			// Best practice close the file stream and work book for leakage
			// issue
			fos.close();
		}

	}
}

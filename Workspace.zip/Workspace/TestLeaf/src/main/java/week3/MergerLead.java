package week3;

public class MergerLead extends WrapperClass {

	@org.junit.Test

	public void merge(){
		launchBrowser("chrome", "http://demo1.opentaps.org/");
		inputTextByID("username", "DemoSalesManager");
		inputTextByID("password", "crmsfa");
		linkClickByClass("decorativeSubmit");
		linkClickByXpath("//*[@id='label']/a");
		linkClickByLinkText("Leads");
		linkClickByLinkText("Merge Leads");
		String currentWind = getCurrentWindowHandle();
		linkClickByXpath("//span[contains(text(), 'From Lead')]/following::a");
		sleepForSec(5000);
		switchToLastWindow();
		inputTextByName("id", "10050");
		linkClickByClass("x-btn-text");
		linkClickByLinkText("10050");
		sleepForSec(2000);
		switchToSpecificWindow(currentWind);
		linkClickByXpath("//span[contains(text(), 'To Lead')]/following::a");
		switchToLastWindow();
		inputTextByName("id", "10039");
		linkClickByLinkText("10039");
		switchToSpecificWindow(currentWind);
		linkClickByClass("buttonDangerous");
		sleepForSec(1000);
		System.out.println("alert main");
		alertHandle("alert","");
		linkClickByLinkText("Find Leads");
		inputTextByName("id", "10161");
		linkClickByXpath("//button[contains(text(),'Find Leads')]");
		verifyTextByClassName("x-paging-info", "No records to display");
	}
}
package week3;

import org.junit.Test;

public class EditContact extends WrapperClass{
	@ Test
	public void editSourceCamp()
	{
		launchBrowser("chrome","http://demo1.opentaps.org/opentaps/control/main");
		inputTextByID("username", "DemoSalesManager");
		inputTextByID("password", "crmsfa");
		linkClickByClass("decorativeSubmit");
		sleepForSec(3000);
		linkClickByXpath("//*[@id='button']/a/img");
		linkClickByLinkText("Contacts");
		linkClickByLinkText("Find Contacts");
		inputTextByXPath("(//input[@name='firstName'])[3]", "Caramel_Gold");
		linkClickByXpath("//button[contains(text(),'Find Contacts')]");
		linkClickByXpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a");
		verifyBrowserTitle("View Contact");
		linkClickByLinkText("Edit");
		selectById("addMarketingCampaignForm_marketingCampaignId","Demo Marketing Campaign");
		linkClickByXpath("(//input[@class='smallSubmit' and @value='Add'])[1]");
		verifyTextByXpath("//table[@class='crmsfaListTable']//a[@class='linktext']", "Demo Marketing Campaign");
		closeBrowser();
	}
}



package week3;

public class MergeContact extends WrapperClass {

	@org.junit.Test

	public void merge(){
		launchBrowser("chrome", "http://demo1.opentaps.org/");
		inputTextByID("username", "DemoSalesManager");
		inputTextByID("password", "crmsfa");
		linkClickByClass("decorativeSubmit");
		linkClickByXpath("//*[@id='label']/a");
		linkClickByLinkText("Contacts");
		linkClickByLinkText("Merge Contacts");
		String currentWind = getCurrentWindowHandle();
		linkClickByXpath("(//*[@class='twoColumnForm']//td[2]/a)[1]");
		sleepForSec(5000);
		switchToLastWindow();
		inputTextByName("id", "10063");
		linkClickByClass("x-btn-text");
		linkClickByLinkText("10063");
		sleepForSec(2000);
		switchToSpecificWindow(currentWind);
		linkClickByXpath("(//*[@class='twoColumnForm']//td[2]/a)[2]");
		switchToLastWindow();
		inputTextByName("id", "10067");
		linkClickByClass("x-btn-text");
		linkClickByLinkText("10067");
		switchToSpecificWindow(currentWind);
		linkClickByClass("buttonDangerous");
		sleepForSec(1000);
		System.out.println("alert main");
		alertHandle("alert","");
		linkClickByLinkText("Find Contacts");
		inputTextByName("id", "10063");
		linkClickByXpath("//button[contains(text(),'Find Contacts')]");
		verifyTextByClassName("x-paging-info", "No records to display");
		closeBrowser();
	}
}
package week3;

import org.junit.Test;

public class CreateLead extends WrapperClass {

	@Test
	public  void main1() {
	
		launchBrowser("firefox","http://demo1.opentaps.org/opentaps/control/main");
		
		inputTextByID("username", "DemoSalesManager");
		inputTextByName("PASSWORD", "crmsfa");
		linkClickByClass("decorativeSubmit");
		
		linkClickByXpath("//*[@id='label']/a");
		linkClickByLinkText("Create Lead");
		
		inputTextByID( "createLeadForm_companyName","xyz");
		inputTextByID( "createLeadForm_firstName", "Caramel_Gold");
    	inputTextByID( "createLeadForm_lastName","Rajaram");
		selectById("createLeadForm_dataSourceId", "Employee");
		selectById("createLeadForm_marketingCampaignId", "Automobile");
		inputTextByID("createLeadForm_primaryEmail","Caramel_Gold@xyz.com");
		inputTextByID("createLeadForm_primaryPhoneNumber", "1234567890");
		linkClickByName("submitButton");
		
		String leadId = driver.findElementById("viewLead_companyName_sp").getText();
		System.out.print("Lead Id: ");
		System.out.printf(leadId.substring(leadId.indexOf("(")+1, leadId.indexOf(")")));
		
	//String[] split = leadId.split(" ");	
	//System.out.println(split[1].replace("(", "").replace(")", ""));	
		
		
				
				
				
				
		
	}

	
}

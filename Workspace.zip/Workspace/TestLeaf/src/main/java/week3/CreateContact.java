package week3;

import org.junit.Test;

public class CreateContact extends WrapperClass {
	@Test
	public  void  main() {

		launchBrowser("firefox","http://demo1.opentaps.org/opentaps/control/main");

		inputTextByID("username", "DemoSalesManager");
		inputTextByName("PASSWORD", "crmsfa");
		linkClickByClass("decorativeSubmit");

		linkClickByXpath("//*[@id='label']/a");
		linkClickByLinkText("Create Contact");


		inputTextByID( "firstNameField", "Caramel_Gold");
		inputTextByID( "lastNameField","Rajaram");
		selectById("createContactForm_generalCountryGeoId", "India");
		inputTextByID("createContactForm_primaryEmail","Caramel_Gold@xyz.com");
		inputTextByID("createContactForm_primaryPhoneNumber", "1234567890");
		linkClickByName("submitButton");

		String leadId = driver.findElementById("viewContact_fullName_sp").getText();
		System.out.print("Lead Id: ");
		System.out.print(leadId.substring(leadId.indexOf("(")+1, leadId.indexOf(")")));
		closeBrowser();








	}

}

package week2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Countframes {

	private static final int Null = 0;

	public static void main(String[] args)   {

		int count = 0;
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://layout.jquery-dev.com/demos/iframes_many.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		List<WebElement> getframe = driver.findElementsByTagName("iframe");
		for (WebElement gf : getframe) {
			driver.switchTo().frame(gf);

			List<WebElement> getnestedframe = driver.findElementsByTagName("iframe");

			if (getnestedframe.size() != Null) {

				count = count + getnestedframe.size();
			}

			driver.switchTo().defaultContent();
		}

		System.out.println("Total outer frames " + getframe.size());
		System.out.println("Total inner frames " + count);
		System.out.println("Total count of frames " + (getframe.size() + count));
	
			try {
				Thread.sleep(0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	}

}

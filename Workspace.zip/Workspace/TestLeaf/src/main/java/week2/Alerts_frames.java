package week2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alerts_frames {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		String str = "ganesh selvam";
		driver.switchTo().frame(driver.findElementByXPath("//*[@id='iframeResult']"));
		driver.findElementByXPath("/html/body/button").click();
		Thread.sleep(5000);
		Alert al1 = driver.switchTo().alert();

		al1.sendKeys(str);
		Thread.sleep(5000);

		al1.accept();
		if (driver.findElementById("demo").getText().contains(str)) {

			System.out.println("verified");
		}

		driver.close();
	}

}

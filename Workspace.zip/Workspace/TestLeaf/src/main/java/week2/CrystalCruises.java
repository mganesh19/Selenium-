package week2;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CrystalCruises {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("http://www.crystalcruises.com/");
		Thread.sleep(5000);
		driver.findElementByLinkText("GUEST CHECK-IN").click();
		Thread.sleep(5000);
		driver.getWindowHandle();
		System.out.println(driver.getWindowHandle());
		Set<String> WindowHandle=driver.getWindowHandles();
		WindowHandle.size();
		for (String GuestLink : WindowHandle) {
			driver.switchTo().window(GuestLink);		
		}
		driver.findElementByLinkText("click here").click();
		Thread.sleep(5000);
		driver.getWindowHandle();
		System.out.println(driver.getWindowHandle());
		Set<String> WindowHandle1=driver.getWindowHandles();
		WindowHandle1.size();
		for (String GuestLink : WindowHandle) {
			driver.switchTo().window(GuestLink);		
		}
		WebElement job = driver.findElementByXPath("//*[@id=':0.targetLanguage']/select");
		Select dropDown = new Select(job); 
		
		dropDown.selectByValue("ta");
		Thread.sleep(5000);
		String content =driver.findElementByTagName("p").getText();
		if(content.contains("à®®à¯�à®©à¯�à®©à¯�à®°à®¿à®®à¯ˆ ")){
			System.out.println("verified:Tamil");
		}
		
		
	}

}

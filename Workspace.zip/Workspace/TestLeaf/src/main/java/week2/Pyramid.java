package week2;

public class Pyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i, j, k = 1;

		for (i = 0; i < 5; i++) {
			for (j = 0; j < k; j++) {
				System.out.print("* ");
			}
			k = k + 2;
			System.out.println();
		}
	}
}

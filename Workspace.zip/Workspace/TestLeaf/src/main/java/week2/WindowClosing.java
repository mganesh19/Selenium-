package week2;

import java.util.Set;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowClosing {

	public static void main(String[] args) {

		   System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
	       ChromeDriver driver=new ChromeDriver();

			driver.get("http://popuptest.com/");

			driver.findElementByLinkText("Multi-PopUp Test #2").click();

			String parentwindow= driver.getWindowHandle();

			//System.out.println(driver.getTitle());

			Set <String> windowhandle=driver.getWindowHandles(); 
			
	          for (String wh : windowhandle) {
	        	  
				if (!wh .equals(parentwindow)) {
					driver.switchTo().window(wh);
					driver.close();
				}
			}
			
			System.out.println(driver.switchTo().window(parentwindow).getTitle());
			driver.close();
			
		}

}

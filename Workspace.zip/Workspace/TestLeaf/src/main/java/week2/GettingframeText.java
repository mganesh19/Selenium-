package week2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class GettingframeText {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://jqueryui.com/draggable/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByLinkText("Draggable").click();
	
		driver.switchTo().frame(0);
		System.out.println("" +driver.findElementByTagName("p").getText());
		driver.switchTo().defaultContent();
		driver.findElementByLinkText("Droppable").click();
		System.out.println("completed");
		driver.close();
	}

}

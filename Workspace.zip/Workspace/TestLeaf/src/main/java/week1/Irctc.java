package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Irctc {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		FirefoxDriver driver = new FirefoxDriver();

		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("userRegistrationForm:userName").sendKeys("mganesh19");

		driver.findElementById("userRegistrationForm:password").sendKeys("G123456");
		driver.findElementById("userRegistrationForm:confpasword").sendKeys("G123456");

		WebElement security_dropdown = driver.findElementByName("userRegistrationForm:securityQ");
		Select select_dropdown= new Select(security_dropdown);
		select_dropdown.selectByIndex(2);

		driver.findElementById("userRegistrationForm:securityAnswer").sendKeys("phone");
		//language dropdown
		WebElement lang_dropdown = driver.findElementByName("userRegistrationForm:prelan");
		Select langselect_dropdown= new Select(lang_dropdown);
		langselect_dropdown.selectByIndex(1);

		driver.findElementById("userRegistrationForm:firstName").sendKeys("ganesh");
		driver.findElementById("userRegistrationForm:middleName").sendKeys("raju");
		driver.findElementById("userRegistrationForm:lastName").sendKeys("M");
		driver.findElementById("userRegistrationForm:gender:0").click();

		
		if(driver.findElementByName("userRegistrationForm:maritalStatus").getText().equalsIgnoreCase(driver.findElementByName("userRegistrationForm:maritalStatus").getText())){
			driver.findElementByName("userRegistrationForm:maritalStatus").click();
			System.out.println("inside condition");
			
		}

		//date dropdown
		WebElement date_dropdown = driver.findElementByName("userRegistrationForm:dobDay");
		Select dateselect_dropdown= new Select(date_dropdown);
		dateselect_dropdown.selectByIndex(10);

		//month dropdown
		WebElement month_dropdown = driver.findElementByName("userRegistrationForm:dobMonth");
		Select monthselect_dropdown= new Select(month_dropdown);
		monthselect_dropdown.selectByIndex(5);

		//year dropdown
		WebElement year_dropdown = driver.findElementByName("userRegistrationForm:dateOfBirth");
		Select yearselect_dropdown= new Select(year_dropdown);
		yearselect_dropdown.selectByIndex(12);

		//occupation dropdown
		WebElement occupation_dropdown = driver.findElementByName("userRegistrationForm:occupation");
		Select occupationselect_dropdown= new Select(occupation_dropdown);
		occupationselect_dropdown.selectByIndex(5);


		driver.findElementById("userRegistrationForm:uidno").sendKeys("52564M");	

		driver.findElementById("userRegistrationForm:idno").sendKeys("165132");	
		driver.findElementByXPath("//*[@id='userRegistrationForm:email']").sendKeys("ganeshmani19@gmail.com");
		driver.findElementById("userRegistrationForm:mobile").sendKeys("9840386952");

		//nationality dropdown

		WebElement nationality_dropdown = driver.findElementByName("userRegistrationForm:nationalityId");
		Select nationalityselect_dropdown= new Select(nationality_dropdown);
		nationalityselect_dropdown.selectByIndex(1);

		driver.findElementById("userRegistrationForm:address").sendKeys("no:28");
		driver.findElementById("userRegistrationForm:street").sendKeys("karunanidhi street");
		driver.findElementById("userRegistrationForm:area").sendKeys("tambaram");


		// countries
		WebElement country_dropdown = driver.findElementByName("userRegistrationForm:countries");
		Select countryselect_dropdown= new Select(country_dropdown);
		countryselect_dropdown.selectByIndex(1);

		WebElement de= driver.findElementById("userRegistrationForm:pincode");
		
		de.sendKeys("600064");
		de.sendKeys(Keys.TAB);
		//Thread.sleep(5000);

		WebDriverWait webwait= new WebDriverWait(driver, 10);
       webwait.until(ExpectedConditions.textToBePresentInElementValue(By.id("userRegistrationForm:statesName"), "TAMIL NADU"));
    		   
    		   
    		   
		// city
		WebElement city_dropdown = driver.findElementByName("userRegistrationForm:cityName");
		Select cityselect_dropdown= new Select(city_dropdown);
		cityselect_dropdown.selectByIndex(1);
		Thread.sleep(5000);

		// postoffice
		WebElement postofficeName_dropdown = driver.findElementByName("userRegistrationForm:postofficeName");
		Select postofficeNameselect_dropdown= new Select(postofficeName_dropdown);
		postofficeNameselect_dropdown.selectByIndex(1);

		driver.findElementById("userRegistrationForm:landline").sendKeys("9840386952");
		driver.findElementByXPath("//*[@id='userRegistrationForm:resAndOff:0']").click();

		//driver.close();
	}


}

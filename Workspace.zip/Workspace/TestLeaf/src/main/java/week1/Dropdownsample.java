package week1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.*;

public class Dropdownsample {

	public static void main(String[] args) {
		
		FirefoxDriver driver = new FirefoxDriver();
		
		
		driver.get("https://developer.salesforce.com/signup?d=70130000000td6N");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement job = driver.findElementById("job_role");
		Select dropDown = new Select(job);
//	dropDown.selectByIndex(2);
//		dropDown.selectByVisibleText("Business Manager/Executive");
		
		List<WebElement> options = ((Select) driver.findElementById("job_role")).getOptions();

		int i= options.size();
		System.out.println("count:"+options.size());
		dropDown.selectByIndex(options.size()-1);
		
		driver.quit();
	}

}

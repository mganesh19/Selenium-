package week1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Getalllinks {

	public static void main(String[] args) {
		 FirefoxDriver driver = new FirefoxDriver();
         int count=0;
	        //Load the URL
	        //syntax to call the method
	        //reference.methodname();
	        
	        driver.get("http://www.google.com");

	        //Maximise the Browser
	        
	        driver.manage().window().maximize();

	        //Set the timeout
	        
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        
	        List<WebElement> alllinks = driver.findElementsByTagName("a");
	
	        
	        for(WebElement we : alllinks){
	        	
	        	if(we.getText().contains("a")){
		        System.out.println(""+ we.getText());
	        	count++;
	        	}
	        }
	       
	      System.out.println("count of total links with a "+count);  
	}

}

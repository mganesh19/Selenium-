package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Gmail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  FirefoxDriver driver = new FirefoxDriver();

	        //Load the URL
	        //syntax to call the method
	        //reference.methodname();
	        
	        driver.get("http://www.gmail.com");

	        //Maximise the Browser
	        
	        driver.manage().window().maximize();

	        //Set the timeout
	        
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        
	        
	        driver.findElementById("Email").sendKeys("ganeshmani19@gmail.com");
	        
	        
	        driver.findElementByName("signIn").click();
	        
	        driver.findElementById("Passwd").sendKeys("Rubamani2073");
	        
	        driver.findElementByXPath("//*[@id='signIn']").click();
	        driver.findElementByXPath("//*[@id='gb']/div[1]/div[1]/div[2]/div[4]/div[1]/a/span").click();
	        
	        driver.findElementByXPath("//*[@id='gb_71']").click();
	      driver.close();
	    
	        
	    
		
	
		
	}

}

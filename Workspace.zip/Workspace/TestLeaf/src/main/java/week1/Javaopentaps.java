package week1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Javaopentaps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//open firefox browser
        //syntax for calling another class
        //classname reference = new classname();
		
        FirefoxDriver driver = new FirefoxDriver();

        //Load the URL
        //syntax to call the method
        //reference.methodname();
        
        driver.get("http://demo1.opentaps.org/opentaps/control/main");
        

        //Maximise the Browser
        
        driver.manage().window().maximize();

        //Set the timeout
        
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        
     driver.findElementById("username").sendKeys("DemoSalesManager");
     
     driver.findElementByName("PASSWORD").sendKeys("crmsfa");
     driver.findElementByXPath("//*[@id='login']/p[3]/input").click();
     driver.findElementByXPath("//*[@id='logout']/input").click();
     
     
     
     
    // driver.findElementsByClassName("decorativeSubmit").click();
    
     
     driver.close();


        
	}

}

package week1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GoogleName {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		String str = "";
		FirefoxDriver driver = new FirefoxDriver();

		driver.get("https://www.google.co.in");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElementById("lst-ib").sendKeys("Ganesh");
		driver.findElementByClassName("lsb").click();
		Thread.sleep(5000);
		List<WebElement> alllinks = driver.findElementsByTagName("a");
		System.out.println("Total number of links " + alllinks.size());

		for (WebElement we : alllinks) {

			str = we.getText().toLowerCase();

			if (str.contains("ganesh") && str.length() > 20) {

				System.out.println("" + we.getText());

			}
		}

		driver.close();
	}

}

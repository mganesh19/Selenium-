package week1;

public class javasamples {

	public static void main(String[] args) {
		
	
	
	
	
	}

}

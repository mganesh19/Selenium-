package week1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Opentabslead {

	public static void main(String[] args) throws InterruptedException {

		FirefoxDriver driver= new FirefoxDriver();
		driver.get("http://demo1.opentaps.org/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElementById("username").sendKeys("DemoSalesManager");
		  driver.findElementByName("PASSWORD").sendKeys("crmsfa");
		  driver.findElementByClassName("decorativeSubmit").click();
		  driver.findElementByXPath("//*[@id='button']/a/img").click();
		  driver.findElementByLinkText("Create Lead").click();
		  
		  Thread.sleep(20000);
		  driver.findElementById("createLeadForm_companyName").sendKeys("ganesh");
		  driver.findElementById("createLeadForm_lastName").sendKeys("M");
		  driver.findElementById("createLeadForm_firstName").sendKeys("Raju");
		  
		  driver.findElementByClassName("smallSubmit").click();
		  
		
          driver.close();

	}


}

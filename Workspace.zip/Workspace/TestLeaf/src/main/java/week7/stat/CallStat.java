package week7.stat;

public class CallStat {
	
	static int i = 1;
	
	public static void main(String[] args) {
		
		AccessStatic.run(); // call run directly from class
		
	}

}

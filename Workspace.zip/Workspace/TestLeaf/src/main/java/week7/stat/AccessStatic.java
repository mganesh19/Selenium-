package week7.stat;

public   class AccessStatic {
	public static final void run(){
		
	}

}

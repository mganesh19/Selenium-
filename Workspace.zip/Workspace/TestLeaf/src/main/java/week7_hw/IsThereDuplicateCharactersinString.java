package week7_hw;

import java.util.LinkedHashMap;
import java.util.Map;


public class IsThereDuplicateCharactersinString {

	public static void main(String[] args) {
		
		// Lets write Psuedocode first
		// Goal ?? If there is repeating character -- then print false ; else true
		
		// 1, Convert the string to the character array(toCharArray())
		// 2, Loop through each character (use foreach)
		// 3, If the character is in map key then print duplicate and break
		// 4, If not add to the map
		
		String date = "Cognizant";
		
		char[] allChars= date.toCharArray();
		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		boolean bDuplicate = false;
		for (char c : allChars) {
			
			if(map.containsKey(c)){
				map.put(c, map.get(c)+1);
				System.out.println("occurances of each character "+c+" : "+map.get(c));
			
			}else{
				map.put(c, 1);
				System.out.println("occurances of each character "+c+" : "+map.get(c));
				
			}
		}
		if(!bDuplicate){
			System.out.println("all Unique Characters");
		}
		
		System.out.println(map);
	
	//Alias:
		
	//Psuedocode
		
			/*
			 PSEUDOCODE:
			 1. Create a LinkedHashMap<Character, Integer>
			 2. Change the given string to lowercase and store it
			 3. Loop through the string from String.Length-1 to 0
			 4. Extract each character from string one by one using charAt(Index)
			 5. Check whether newly extracted character exist on Map already using containsKey(Key)
			 6. If exist, increment the Interger value by 1
			 7. else, put(character, 1)
			 8. Print the map using sysout
			 */
	
		//Map declaration
				Map<Character, Integer> characterMap = new LinkedHashMap<Character, Integer>();
				
				String name = "COGNizant";
				name = name.toLowerCase();
				
				char newChar;
				//Loop through and finding which elements occurs how many times
				for(int iLoop = name.length()-1; iLoop>=0; iLoop--)
				{
					newChar = name.charAt(iLoop);
					if(characterMap.containsKey(newChar))
					{
						characterMap.put(newChar, characterMap.get(newChar) + 1);
					}
					else
					{
						characterMap.put(newChar, 1);
					}
				}
				
				//Print the Map
				System.out.println(characterMap);
	
	
	
	
	
	
	
	
	}

	
	
	
	
	
	
	
}

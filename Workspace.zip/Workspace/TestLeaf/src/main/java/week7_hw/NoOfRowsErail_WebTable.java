package week7_hw;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NoOfRowsErail_WebTable {

	public static void main(String[] args) {
		//Creating driver for chrome browser
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();

		//Load the URL
		driver.get("http://erail.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Input From station
		driver.findElementById("txtStationFrom").clear();
		driver.findElementById("txtStationFrom").sendKeys("MAS");
		driver.findElementById("txtStationFrom").sendKeys(Keys.TAB);
		
		//Input From station
		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("SBC");
		driver.findElementById("txtStationTo").sendKeys(Keys.TAB);
		
		//Finding the number of rows
		WebElement oTable = driver.findElementByXPath("//table[@class='DataTable TrainList']");
		System.out.println("Number of rows in the page: " + oTable.findElements(By.tagName("TR")).size());
		
		//close the browser
		driver.close();
	}

}
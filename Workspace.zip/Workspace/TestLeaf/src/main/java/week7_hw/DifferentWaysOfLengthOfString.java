package week7_hw;

public class DifferentWaysOfLengthOfString {

	public static void main(String[] args) {
		String name = "ganesh";
		System.out.println("String is: " + name);
		
		// First Method
		System.out.println("First Method");
		name = name + "/";
		System.out.println("Length of String: " + name.indexOf("/"));
		name = name.replace("/", "");
		
		//Second Method
		System.out.println("Second Method");
		System.out.println("Length of String: " + name.toCharArray().length);
		
		//Third Method
		System.out.println("Third Method");
		System.out.println("Length of String: " + new StringBuilder(name).length());
		
		//Using Length Method
		System.out.println("Using Length Method");
		System.out.println("Length of String: " + name.length());
		
		//Using Split
		System.out.println("Using Split Method");
		System.out.println("Length of String: " + name.split("").length);
	}

}

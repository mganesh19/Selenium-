package week7_hw;

import java.util.Arrays;

public class ReverseArraySort {

	public static void main(String[] args) {
		//String Array Declaration
		String[] companyNameArray = {"infosys", "cognizant", "tcs", "verizon"};
		String[] reverseArray = new String[companyNameArray.length];
		
		//sorting the Array
		Arrays.sort(companyNameArray);
		
		//Print in reverse order
		System.out.println("Companies Name in reverse order");
		int j = 0;
		for(int i=companyNameArray.length-1; i>=0; i--)
		{
			reverseArray[j] = companyNameArray[i];
			System.out.println(reverseArray[j]);
			j++;
		}
	}

}


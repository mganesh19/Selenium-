package week7_hw;

import java.util.LinkedHashMap;
import java.util.Map;
public class MostRepeatedChar {

	public static void main(String[] args) {
		//Map declaration
		Map<Character, Integer> characterMap = new LinkedHashMap<Character, Integer>();
		
		String name = "Amazon Development Centre";
		name = name.toLowerCase();
		
		char newChar;
		char maxChar = 'a';
		int maxOccurence=1;
		//Loop through and finding which elements occurs how many times
		for(int iLoop = name.length()-1; iLoop>=0; iLoop--)
		{
			newChar = name.charAt(iLoop);
			if(characterMap.containsKey(newChar))
			{
				characterMap.put(newChar, characterMap.get(newChar) + 1);
				if(characterMap.get(newChar) > maxOccurence)
				{
					maxChar = newChar;
					maxOccurence = characterMap.get(newChar);
				}
			}
			else
			{
				characterMap.put(newChar, 1);
			}
		}
		
		//Print the Map
		System.out.println(characterMap);
		System.out.println("Character occured more is: " + maxChar);
		System.out.println("Number of times it occured: " + maxOccurence);
	}

}
	


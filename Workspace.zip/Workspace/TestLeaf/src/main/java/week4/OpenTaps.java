package week4;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class OpenTaps extends TestngAnnotation {
	
	 
	  
	  @Test(invocationCount=2, threadPoolSize=2)
	  public void createLead() {	   
		  System.out.println("This is @Test-createLed");	
	  }
	  
	  @Test(enabled=false)
	  public void findLead() {	   
		  System.out.println("This is @Test-findLead");	
	  }
	  
	  @Test(dependsOnMethods="createLead",invocationTimeOut=10000)
	  public void createContact() throws InterruptedException {	   
		  System.out.println("This is @Test-createContact");	
//		  Thread.sleep(12000);
	  }
	  
	  @BeforeMethod(description="Entering username and password")
//	  @Parameters("browser")
	 /* public void beforeMethod(String browsername) { 
		  System.out.println("Launching Browser" + browsername); 
	  }*/
	  public void beforeMethod() { 
		  System.out.println("Launching Browser"); 
	  }

	  @AfterMethod
	  public void afterMethod() {
		  System.out.println("This is @AfterMethod - Logout");
	  }

	  @BeforeClass(description="Launching Firefox Browser and loading the url")
	  public void beforeClass() {
		  System.out.println("This is @BeforeClass");
	  }

	  @AfterClass(alwaysRun=true)
	  public void afterClass() {
		  System.out.println("This is @AfterClass");
			
	  }

	  @DataProvider(name="testdata")
	  public Object dataprovider(){
	  Object test= new Object[2][5];
	 
	  
	  return test;
	  }
}

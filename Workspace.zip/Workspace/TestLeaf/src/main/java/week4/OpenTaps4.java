package week4;

import java.util.concurrent.TimeoutException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.internal.thread.ThreadExecutionException;

public class OpenTaps4 extends TestngAnnotation {

	//@Test(invocationCount=3,threadPoolSize=3,invocationTimeOut=2000)
	
	
	@Test
	public void createLead() throws InterruptedException {
		System.out.println("4 This is @Test-createLed");
	Thread.sleep(2000);
	}

	/*@Test(dependsOnMethods = "createLead", timeOut = 599)
	public void createContact() throws InterruptedException {
		System.out.println(" 4 This is @Test-createContact");
		Thread.sleep(500);

	}
*/
	@BeforeMethod(description = "Entering username and password",timeOut = 499)
	public void beforeMethod() {
		
			
			System.out.println(" 4 @BeforeMethod");
		//	Thread.sleep(2000);	
		
	    }

	@AfterMethod
	public void afterMethod() {
		System.out.println("4 This is @AfterMethod - Logout");
	}

	@BeforeClass(description = " 4 Launching Firefox Browser and loading the url")
	public void beforeClass() {
		System.out.println("4 This is @BeforeClass");
	}

//	@AfterClass(alwaysRun = true)
	@AfterClass
	public void afterClass() {
		System.out.println(" 4 This is @AfterClass");

	}

}

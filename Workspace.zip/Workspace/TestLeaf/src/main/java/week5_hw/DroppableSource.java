package week5_hw;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class DroppableSource {
	@Test
	public void f() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.get("http://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// driver.switchTo().frame(driver.findElementByClassName("demo-frame"));

		Actions builderActions = new Actions(driver);
		builderActions.keyDown(Keys.CONTROL).sendKeys("u").keyUp(Keys.CONTROL).perform();

		String parentwindow = driver.getWindowHandle();

		Set<String> windowhandle = driver.getWindowHandles();
		System.out.println("windows count " + windowhandle.size());

		for (String wh : windowhandle) {

			driver.switchTo().window(wh);
			System.out.println(driver.switchTo().window(wh).getTitle());

			if (!wh.equals(parentwindow)) {

				driver.close();
			}
		}

		System.out.println("windows count " + driver.getWindowHandles().size());
		System.out.println(driver.switchTo().window(parentwindow).getTitle());
	}
}
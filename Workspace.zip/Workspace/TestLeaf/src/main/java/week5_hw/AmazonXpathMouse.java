package week5_hw;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class AmazonXpathMouse
{

	@Test
	public void amazonXpath() throws InterruptedException
	{
		//Creating driver for chrome browser
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		//Declare variable for storing URL
		String baseUrl = "http://www.amazon.in/";

		//launch the URL
		driver.get(baseUrl);

		Thread.sleep(14000);
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		/*Mouse over 'Sort by Category'
		Navigate to "Books" >> "All Books"*/
		Thread.sleep(2000);
		Actions builder = new Actions(driver);
		//builder.moveToElement(driver.findElementByXPath("//div[@id='nav-shop']")).moveToElement(driver.findElementByXPath("(//span[text()='Books'])[1]")).moveToElement(driver.findElementByXPath("(//span[text()='All Books'])[1]")).click().build().perform();
		WebElement elem = driver.findElementByXPath("//div[@id='nav-shop']");
		System.out.println("element text" + elem.getText());
		builder.moveToElement(elem).pause(2000).perform();
		WebElement elem1 = driver.findElementByXPath("(//span[text()='Books'])[1]");
		System.out.println("element text" + elem1.getText());
		builder.moveToElement(elem1).perform();
		WebElement elem2 = driver.findElementByXPath("(//span[text()='All Books'])[1]");
		System.out.println("element text" + elem2.getText());
		builder.moveToElement(elem2).click().build().perform();
		
		/*Find out how many GENERES are displayed
		Click on the 4th GENERE (Under "BROWSE THROUGH GENRES")*/
		Thread.sleep(2000);
		driver.findElementByXPath("(//div[@class='fluid-grid-container fg-is-not-mobile fg-container'])[2]/div[2]/ul/li[4]/descendant::a[1]").click();
		Thread.sleep(2000);
		
		/*[after loading the next page]
		Find out how many categories are displayed under "Computer Science Textbooks" genre.*/
		List<WebElement> lstComputerCategory = driver.findElementsByXPath("//h2[text()='Computer Science Textbooks']/following::div[starts-with(@class,'row a-fixed-left-grid aui-showgrid')][1]/descendant::div[starts-with(@class,'fluid asin')]");
		System.out.println("Number of categories under 'Computer Science Textbooks' are: " + lstComputerCategory.size());
		
		/*Click on the 3rd category under "Computer Science Textbooks" */
		lstComputerCategory.get(2).click();
		System.out.println("Last Book Name is : " + lstComputerCategory.get(2).getText());
		/*int iLoop = 1;
		for (WebElement lstCategory : lstComputerCategory) {
			if(iLoop == 3)
				lstCategory.click();
			iLoop++;
		}*/
		
		Thread.sleep(2000);
		
		/*[after loading the next page]v
		Find out how many books are displayed in the page#1.*/
		List<WebElement> lstBooks = driver.findElementsByXPath("//li[starts-with(@id,'result')]");
		int booksCount = lstBooks.size();
		System.out.println("Number of Books listed on the page are : " + booksCount);
		
		System.out.println("Last Book Name is : " + lstBooks.get(booksCount-1).getText());
		lstBooks.get(booksCount-1).click();
		
		Thread.sleep(2000);
		
		driver.close();
	}
}


/*
element textShop by
Category
element textBooks
element text
Number of categories under 'Computer Science Textbooks' are: 4
Last Book Name is : Programming Languages
Number of Books listed on the page are : 16
Last Book Name is : Data Structures Using C11 June 2014
by Reema Thareja
Paperback
  399.00  485.00Fulfilled
You Save:   86.00 (17%)
5 out of 5 stars
6

Cash on Delivery eligible.
PASSED: amazonXpath
*/
package week5_hw;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelToDataProvider
{
	@Test(description="OpenTaps Login method", dataProvider="LoginOpenTaps")
	public void excelToDataProvider(String userName, String pwd,String col3,String col4,String col5)
	{
		System.out.println("OpenTaps Login test method going to run with UserName: " + userName + "; Password: " + pwd);
		
		//Declare variable for storing URL
		//String baseUrl = "http://demo1.opentaps.org/";

		//Implicit Wait
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		//ChromeDriver driver = new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.manage().window().maximize();

		//launch the URL
		//driver.get(baseUrl);
		//Input UserName
		//driver.findElementById("username").sendKeys(userName);

		//Input Password
		//driver.findElementById("password").sendKeys(pwd);

		System.out.println("parameter3 :"+col3+"\n" +"parameter4 :"+col4+"\n" +"parameter5 :"+col5+"\n"  );
		
		//Clicking on Login button
		//driver.findElementByClassName("decorativeSubmit").click();

		//Clicking on Logout button
	//	driver.findElementByXPath("//form[@id='logout']/input").click();
		
		//driver.close();

	}
	
	@DataProvider(name="LoginOpenTaps")
	public Object[][] getLoginData() throws IOException
	{
		Object[][] dataFromExcel = getDataFromExcel();
		return dataFromExcel;
	}
	
	public String[][] getDataFromExcel() throws IOException
	{
		
		//Rows - Number of times your test has to be repeated.
		//Columns - Number of parameters in test data.you can have many number of columns as possible
		String[][] loginDataArray = new String[2][5];

		FileInputStream fis = new FileInputStream(new File("./test/Login.xlsx"));
		XSSFWorkbook wBook = new XSSFWorkbook(fis);
		XSSFSheet wSheet = wBook.getSheet("Login");
		int rCount = wSheet.getLastRowNum();
		System.out.println("Number of rows in excel: " + rCount);
		for(int iLoop = 1; iLoop <= rCount; iLoop++)
		{
			XSSFRow wRow = wSheet.getRow(iLoop);
			
			System.out.println("UserName: " + wRow.getCell(0).getStringCellValue());
			loginDataArray[iLoop-1][0] = wRow.getCell(0).getStringCellValue();
			loginDataArray[iLoop-1][1] = wRow.getCell(1).getStringCellValue();
			loginDataArray[iLoop-1][2] = wRow.getCell(2).getStringCellValue();
			loginDataArray[iLoop-1][3] = wRow.getCell(3).getStringCellValue();
			loginDataArray[iLoop-1][4] = wRow.getCell(4).getStringCellValue();
			
		
		
		}
		
		//close the FileInputStream	 and workbook
		fis.close();
		wBook.close();
		
		return loginDataArray;
	}
}

package testcases;

public class ReadProp {

	
	public static void main(String[] args) {
		
	

	}

}

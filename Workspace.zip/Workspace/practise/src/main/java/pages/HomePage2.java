package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import Wrapper.Wrapper;

public class HomePage2  extends Wrapper{

	public HomePage2() {
		System.out.println("inside Homepage2 ");
		}
	public LoginPage navigateBack() {
		
		System.out.println("inside Homepage2 click");
		
		
		return new LoginPage();

	}
}
package pages;


import Wrapper.Wrapper;
import Wrapper.GenericWrapper;

public class LoginPage extends Wrapper{
	
	public LoginPage() {
		System.out.println("inside login");
	}
	
public HomePage Login(String username, String password){
	System.out.println("inside login click");
	enterById("username",username);
	enterById("password",password);
	clickByClassName("decorativeSubmit");
	return new HomePage();
	}
	
	
}
package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.internal.FindsById;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import Wrapper.Wrapper;


public class HomePage  extends Wrapper{

	

	public HomePage() {
		System.out.println("inside Homepage ");
		}

	public void navigate(String drpValue) {
		System.out.println("inside Homepage click ");
		clickByXpath("//*[@id='label']/a");
		clickByLink("Create Contact");

		Select select = new Select(driver.findElementById("createContactForm_preferredCurrencyUomId"));
		List<WebElement> lst= select.getOptions();	
		
		for (WebElement webElement : lst) {

			if(webElement.getText().equalsIgnoreCase(drpValue)){
				
				select.selectByValue(webElement.getText());
				
			}
		}
		}

		
		
	
	}


	

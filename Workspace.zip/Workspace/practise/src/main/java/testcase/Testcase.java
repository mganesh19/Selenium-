/**
 * 
 */
/**
 * @author raju
 *
 */
package testcase;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Wrapper.Wrapper;
import pages.LoginPage;


public class Testcase extends Wrapper{
	
	
	@BeforeClass
	public void setData(){
		browserName="mozilla";
		dataSheetName="TC001";
		testCaseName="Login";
		testDescription="Login application";
		url="http://demo1.opentaps.org/opentaps/control/main";
		System.out.println("before class");
	}
	
	@Test(dataProvider="fetchData")
	public void testRun(String Username,String password,String checkdropdown, String selectradio) {
		
		new LoginPage().Login(Username,password).navigate(checkdropdown);
		
	}
	

	
}
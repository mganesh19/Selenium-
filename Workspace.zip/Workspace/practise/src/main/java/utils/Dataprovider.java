
package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Dataprovider {

	 public static String[][] getdata(String sheetName) {

		String [][] data = null ;
		
		try {
			FileInputStream fis = new FileInputStream(new File("./data/TC001.xlsx"));
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);

			int rowcount = sheet.getLastRowNum();
			int coloumnscount = sheet.getRow(0).getLastCellNum();
            data=new String[rowcount][coloumnscount];
			for (int i = 1; i < rowcount + 1; i++) {

				XSSFRow row = sheet.getRow(i);

				for (int j = 0; j < coloumnscount; j++) {
					try {
						String cellValue = "";
						try{
							cellValue = row.getCell(j).getStringCellValue();
						}catch(NullPointerException e){

						}

						data[i-1][j]  = cellValue; // add to the data array
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					

				}

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;

	}
}
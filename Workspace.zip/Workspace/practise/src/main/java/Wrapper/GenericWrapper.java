package Wrapper;
 
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;



public class GenericWrapper {

	protected static RemoteWebDriver driver;
	
	public void invokeApp(String browser, String sUrl) {
		boolean bReturn = false;
		try {

			if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			
			}else
				driver = new FirefoxDriver();
			
			driver.get(sUrl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			bReturn = true;

		} catch (Exception e) {
			e.printStackTrace();
		
		}
		
	}
	
	
	public boolean enterById(String idValue, String data) {
		boolean bReturn = false;
		try {
			driver.findElement(By.id(idValue)).clear();
			driver.findElement(By.id(idValue)).sendKeys(data);	
		

		} catch (Exception e) {
		
		}
		return bReturn;
	}

	
	public boolean verifyTitle(String title){
		boolean bReturn = false;
		try{
			if (driver.getTitle().equalsIgnoreCase(title)){
				
				bReturn = true;
			}
				

		}catch (Exception e) {
			
		}

		return bReturn;
	}

	
	public boolean verifyTextByXpath(String xpath, String text){
		boolean bReturn = false;
		String sText = driver.findElementByXPath(xpath).getText();
		if (driver.findElementByXPath(xpath).getText().trim().equalsIgnoreCase(text)){
		
			bReturn = true;
		}else{
			
		}


		return bReturn;
	}
	
	public boolean verifyTextContainsByXpath(String xpath, String text){
		boolean bReturn = false;
		String sText = driver.findElementByXPath(xpath).getText();
		if (driver.findElementByXPath(xpath).getText().trim().contains(text)){
		
			bReturn = true;
		}else{
			
		}


		return bReturn;
	}

	public void quitBrowser() {
		try {
			driver.quit();
		} catch (Exception e) {
			
		}

	}


	public boolean clickById(String id) {
		boolean bReturn = false;
		try{
			driver.findElement(By.id(id)).click();
			

			bReturn = true;

		} catch (Exception e) {
		
		}
		return bReturn;
	}

	
	public boolean clickByClassName(String classVal) {
		boolean bReturn = false;
		try{
			driver.findElement(By.className(classVal)).click();
		

			bReturn = true;

		} catch (Exception e) {
			
		}
		return bReturn;
	}

	public boolean clickByName(String name) {
		boolean bReturn = false;
		try{
			driver.findElement(By.name(name)).click();
		

			bReturn = true;

		} catch (Exception e) {
			
		}
		return bReturn;
	}


	public boolean clickByLink(String name) {
		boolean bReturn = false;
		try{
			driver.findElement(By.linkText(name)).click();
			
			bReturn = true;

		} catch (Exception e) {
			
		}
		return bReturn;
	}

	
	public boolean clickByXpath(String xpathVal) {
		boolean bReturn = false;
		try{
			driver.findElement(By.xpath(xpathVal)).click();
			

			bReturn = true;

		} catch (Exception e) {
			
		}
		return bReturn;
	}

	
	public boolean mouseOverByXpath(String xpathVal) {
		boolean bReturn = false;
		try{
			new Actions(driver).moveToElement(driver.findElement(By.xpath(xpathVal))).build().perform();
			
			bReturn = true;

		} catch (Exception e) {
			
		}
		return bReturn;
	}

	
	public boolean mouseOverByLinkText(String linkName) {
		boolean bReturn = false;
		try{
			new Actions(driver).moveToElement(driver.findElement(By.linkText(linkName))).build().perform();
			
			bReturn = true;

		} catch (Exception e) {
			
		}
		return bReturn;
	}

	public String getTextByXpath(String xpathVal){
		String bReturn = "";
		try{
			return driver.findElement(By.xpath(xpathVal)).getText();
		} catch (Exception e) {
			
		}
		return bReturn; 
	}


	public boolean selectById(String id, String value) {
		boolean bReturn = false;
		try{
			new Select(driver.findElement(By.id(id))).selectByVisibleText(value);;
		
			bReturn = true;

		} catch (Exception e) {
		
		}
		return bReturn;
	}
	

}


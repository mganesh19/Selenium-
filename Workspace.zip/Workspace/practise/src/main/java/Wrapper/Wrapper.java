package Wrapper;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import utils.Dataprovider;

public class Wrapper extends GenericWrapper{
	
	protected String browserName;
	protected String dataSheetName;
	protected static String testCaseName;
	protected static String testDescription;
	protected static String url;
	
	@BeforeSuite
	public void beforeSuite() throws FileNotFoundException, IOException{
System.out.println("started before suite");		
	}

	@BeforeTest
	public void beforeTest(){
		System.out.println("started before test");		

	}
	
	@BeforeMethod
	public void beforeMethod(){
		System.out.println("started before method"+ browserName+"   " + url);		

		invokeApp(browserName,url);
	System.out.println("started before method");		
	}
		
	@AfterSuite
	public void afterSuite(){
		System.out.println("started after suite");		
	}

	@AfterTest
	public void afterTest(){
		System.out.println("started after test");		
	}
	
	@AfterMethod(alwaysRun=true)
	public void afterMethod(){
		quitBrowser();
		System.out.println("started before method");		
	}
	
	@DataProvider(name="fetchData")
	public Object[][] getData(){
		return Dataprovider.getdata(dataSheetName);		
	}		
}

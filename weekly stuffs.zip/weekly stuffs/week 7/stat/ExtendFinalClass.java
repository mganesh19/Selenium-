package stat;

public class ExtendFinalClass extends AccessStatic {

	// Final Classes can't be inherited
	public void test() {

	}
}

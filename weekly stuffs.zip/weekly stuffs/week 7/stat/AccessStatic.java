package stat;

public   class AccessStatic {
	public static final void run(){
		
	}

}

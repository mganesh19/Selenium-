package week3;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NoSuchElementExceptionPractise {

	static FirefoxDriver driver = new FirefoxDriver();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// NoSuchElementException
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MICROSECONDS);
		driver.manage().window().maximize();

		driver.get("http://demo1.opentaps.org");

		driver.findElementByName("USERNAME").sendKeys("DemoSalesManager");
		driver.findElementByName("PASSWORD").sendKeys("crmsfa");
		driver.findElementByXPath("//*[@id='login']/p[3]/input").click();

		verifyTitle();

		clickCRMSFA();

		closeBrowser();
	}

	public static void verifyTitle() {

		try {
			WebElement element = driver.findElementByXPath("/html/body/div[2]/div[2]/div[1]/h2");
			String title = element.getText();
			System.out.println(title);
		} catch (NoSuchElementException e) {

			System.out.println("NoSuchElementExceptionPractise ->verifyTitle() -> NoSuchElementException ::  "
					+ e.getLocalizedMessage());
		}

	}

	public static void clickCRMSFA() {
		try {
			Thread.sleep(5000);
			driver.findElementByXPath("/html/body/div[2]/div[2]/div[2]/div[1]/div/a").click();
		} catch (InterruptedException e) {
			System.out.println("NoSuchElementExceptionPractise ->clickCRMSFA() -> InterruptedException ::  "
					+ e.getLocalizedMessage());
		} catch (NoSuchElementException e) {
			System.out.println("NoSuchElementExceptionPractise ->clickCRMSFA() -> NoSuchElementException ::  "
					+ e.getLocalizedMessage());
		}

	}

	public static void closeBrowser() {
		driver.close();
	}

}

package week3;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ExceptionHandling {

	public static void main(String[] args) {
		
	}
	
	public void method0(){
		method1();				// calling method1
	}
	
	public void method1(){
		handleUsingTryCatch();
		try {
			handleUsingThrows();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void handleUsingThrows() throws InterruptedException, WebDriverException{ 
		Thread.sleep(30);					// This line Throws InterruptedException
		WebDriver driver = new FirefoxDriver();			// This line Throws WebDriverException
		throw new NullPointerException();
		
	}
	
	public void handleUsingTryCatch(){ 
		try {
			Thread.sleep(30);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	

}

package week3;

import org.junit.Test;

public class LoginOpenTaps extends Wrapper {
	@Test
	public void createLead() {
	launchBrowser("chrome", "http://demo1.opentaps.org/");
	enterTextById("username", "DemoSalesManager" );
	enterTextById("password", "crmsfa");
	clickByClassName("decorativeSubmit");
	closeBrowser();
	
	/*String welcomeText = driver.findElementByXPath("//*[@id='form']/h2").getText();
	System.out.println(welcomeText);
	
	if(welcomeText.contains("Demo Sales Manager")){
		System.out.println("Verified Successfully");
	} 
	else	{
		System.out.println("Welcome text does not match");
	}
	
	System.out.println(driver.getTitle());
	System.out.println(driver.getCurrentUrl());
	
	driver.findElementByClassName("decorativeSubmit").click();
	driver.close();*/
	}

}

package week3;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
/**
 * 
 * @author Kadhar
 * This class has wrapper methods
 *  common to test case
 */
public class Wrapper {

	RemoteWebDriver driver;
	int snapCounter = 1;

	/**
	 * 
	 * @param browserName
	 * @param url
	 * This method launch browser
	 * pass browser name and url to launch
	 */
	public void launchBrowser(String browserName, String url) {
		try {
			if (browserName.equalsIgnoreCase("firefox")) {
				driver = new FirefoxDriver();
			} else if (browserName.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			}
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get(url);
		} catch (WebDriverException e) {
			System.out.println(" launchBrowser () :: Browser can't be launch ");
		} finally {
			takeSnapShot();
		}

	}
 
	/**
	 * This method take snap shot and 
	 * store it in workspace
	 */
	public void takeSnapShot() {
		File snap = driver.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(snap, new File("./images/snap_" + snapCounter + ".jpeg"));
			snapCounter++;
		} catch (IOException e) {
			System.out.println("Unable to take snapshot");
		}
	}

	public void enterTextById(String id, String value){
		try {
			driver.findElementById(id).clear();
			driver.findElementById(id).sendKeys(value);
		} catch (NoSuchElementException e) {
			System.out.println(" Element with id "+ id + " is not available");
		}finally{
			takeSnapShot();
		}
	}
	public void clickByClassName(String className){
		try {
			driver.findElementByClassName(className).click();
		} catch (NoSuchElementException e) {
			System.out.println(" Element with className "+ className + " is not available");
		}finally{
			takeSnapShot();
		}
	}
	public void closeBrowser() {
		try {
			driver.close();
		} catch (WebDriverException e) {
			System.out.println(" Can't be close");
		}finally{
			// Don't call this, because driver object is closed already
//			takeSnapShot();
		}
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

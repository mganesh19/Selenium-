package week3;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CapturingScreenshots {

	public static void main(String[] args) throws IOException {
		FirefoxDriver driver = new FirefoxDriver();

		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MICROSECONDS);
		driver.manage().window().maximize();

		driver.get("https://www.google.com/?gws_rd=ssl");
		
		File snap= driver.getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(snap, new File("./images/google.jpeg"));
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

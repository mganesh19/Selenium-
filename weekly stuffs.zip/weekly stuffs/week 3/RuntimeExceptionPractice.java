package week3;

public class RuntimeExceptionPractice {

	 public static void main(String[] args) throws ArithmeticException {
		try {
			int a = 10;
			System.out.println(a / 0);
		}catch (ArithmeticException e) {
			System.out.println("am in catch");
		}finally {
			System.out.println("am in final");
		}
		
		System.out.println("Exception done");
		 
			/*	int a = 10;
				System.out.println(a / 0);*/
	}
	 
	

}

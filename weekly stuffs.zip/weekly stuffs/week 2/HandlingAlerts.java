package week2_april;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.get("http://www.w3schools.com/js/tryit.asp?filename=tryjs_alert");
		
		driver.switchTo().frame("iframeResult");
		
		driver.findElementByXPath("/html/body/button").click();
		
		Thread.sleep(5000);
		
		Alert myAlert = driver.switchTo().alert();
		
		myAlert.accept(); 
		
		System.out.println(driver.findElementByXPath("/html/body/p").getText());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

package week2_april;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HandlingFrame {

	public static void main(String[] args) {
		
//		FirefoxDriver driver = new FirefoxDriver();
		
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.get("http://jqueryui.com/draggable/");
		
		driver.switchTo().frame(driver.findElementByClassName(("demo-frame")));
		
		System.out.println(driver.findElementById("draggable").getText());
		
		
		driver.switchTo().defaultContent();
		
		System.out.println(driver.findElementByClassName("entry-title").getText());
		
		
		
		
		
		
		
		
		
		
		
		

	}

}

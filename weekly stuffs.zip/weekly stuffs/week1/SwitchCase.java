package week1.day2;

public class SwitchCase {
	public static void main(String[] args) {
		swichCase("TUE");
	}

public static void swichCase(String day) {
	switch (day) {
	case "SUN":
		System.out.println("Sun day");
		break;
	case "MON":
		System.out.println("Mon day");
		break;
	default:
		System.out.println("Sorry Invalid Entry");
	}

	
	
	
	
	
}
}
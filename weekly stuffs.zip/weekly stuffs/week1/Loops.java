package week1.day2;

import java.util.ArrayList;
import java.util.List;

public class Loops {
	public void loopsEx() {

		// print numbers from 1 to 10
		for (int i = 0; i < 10; i++) {
			System.out.println("Normal for loop :: " + i);
		}

		List<String> names = new ArrayList<String>();

		names.add("Karim");
		names.add("Kadhar");
		names.add("Babu");
		names.add("Sakthi");

		for (String list : names) {
			System.out.println("Foreach loop for collection :: " + list + names.size());
		}

		for (int i = 0; i < names.size(); i++) {

			System.out.println("for loop for collection ::  " + names.get(i));

		}

		int i = 0;
		while (i < names.size()) {

			System.out.println(" while loop for collection :: " + names.get(i));
			i++;
		}

		do {
			System.out.println("Please enter your PIN ");
		} while (false);

		while (true) {
			System.out.println("I am infinite");
		}

	}

	
	
	
	
	
	
}

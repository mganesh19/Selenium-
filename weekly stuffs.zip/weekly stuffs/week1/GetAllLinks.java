package week1.day2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GetAllLinks {

	public static void main(String[] args) {
		FirefoxDriver driver = new FirefoxDriver();
		driver.get("https://www.google.co.in");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		List<WebElement> allLinks = driver.findElementsByTagName("a");
		System.out.println("No of links in Google Pages :- " + allLinks.size());

		for (WebElement link : allLinks) {
			System.out.println(link.isDisplayed());
			System.out.println(link.getText());
			if (link.getText().contains("a") || link.getText().contains("A")) {

			}
		}
		
		for (int i = 0; i < 10; i++) {
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}

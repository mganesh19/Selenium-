package week1.day2;

public class Holidays {

	private String privateHoliday = "Feb 14";

	public String publicHolidays = "Jan 1, May 1";

	protected String floatingHolidays = "Bakrith, Ugadi, Oanam";

	String defaultHoliday = "Sat and Sun";
	
	public boolean method1(){
		
		System.out.println(privateHoliday);
		System.out.println(publicHolidays);
		System.out.println(floatingHolidays);
		return false;
	}
	
	public void printHoliday(){
		
		method1();
	}
	
	
	
	
	
	
	

}

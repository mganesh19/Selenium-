package week5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ClassRoom {
	
	@Test
	public void testStatus() throws IOException {
		
		String bTestStaus = "FAIL";

		// Use output stream to write and append the data in excel
		FileOutputStream fos = new FileOutputStream
				(new File("./data/TestReport.xlsx"));

		// Create work book
		XSSFWorkbook wBook = new XSSFWorkbook();

		// Create sheet
		XSSFSheet sheet = wBook.createSheet("Report");

		// Create row
		XSSFRow rowHeader = sheet.createRow(0);

		// create cell - 1
		XSSFCell cell = rowHeader.createCell(0);

		// Give cell - 1
		cell.setCellValue("Test case Name");

		// create cell - 2
		XSSFCell cell1 = rowHeader.createCell(1);

		// Give cell - 2
		cell1.setCellValue("Status");


		try {
			// Create file input stream - For read use input Stream
			FileInputStream fis = new FileInputStream(new File("./data/Login.xlsx"));

			// Open the workbook
			XSSFWorkbook wBook2 = new XSSFWorkbook(fis);

			// Go to the sheet
			XSSFSheet sheet2 = wBook2.getSheetAt(0);

			// This return no of row in excel sheet
			int rowCount = sheet2.getLastRowNum();

			// Iterate it and print
			for (int i = 1; i <= rowCount; i++) {

				// Go to row
				XSSFRow row = sheet2.getRow(i);

				// Go to cell and read
				System.out.println("user name :: " + row.getCell(0).getStringCellValue());
				System.out.println("password :: " + row.getCell(1).getStringCellValue());
				
				//classname reference = new classname();
				FirefoxDriver driver = new FirefoxDriver();
				
				//Load the URL
				//syntax to call the method
				//reference.methodname();
				driver.get("http://demo1.opentaps.org/opentaps/control/main");
				
				//Maximise the Browser
				driver.manage().window().maximize();
				
				//Set the timeout
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				//enter the username
				driver.findElementById("username").sendKeys(row.getCell(0).getStringCellValue());
				
				//enter the password
				driver.findElementByName("PASSWORD").sendKeys(row.getCell(1).getStringCellValue());
				
				// Click Login Button
				driver.findElementByClassName("decorativeSubmit").click();
				
				//Click Logout button
				driver.findElementByXPath("//*[@id='logout']/input").click();
				
				//Close the Browser
				driver.close();
				
				
				
				bTestStaus = "PASS";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			
			// Create row
			XSSFRow row = sheet.createRow(1);
			// create cell - 1
			XSSFCell cell3 = row.createCell(0);
			// Give cell name
			cell3.setCellValue("Login to OpenTaps");

			// create cell - 2
			XSSFCell cell4 = row.createCell(1);
			// Give cell name
			cell4.setCellValue(bTestStaus);

			// Write is must , unless it doesn't write the data in your excel sheet
			wBook.write(fos);
			// Best practice close the file stream and work book for leakage issue
			fos.close();
			wBook.close();	

		}

	}

}

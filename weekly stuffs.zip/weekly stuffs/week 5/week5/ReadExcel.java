package week5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadExcel {
	@Test
	public void readExcel() throws IOException {
	
		// Create file input stream - For read use input Stream
		FileInputStream fis = new FileInputStream(new File("./data/Login.xlsx"));
		
		// Open the workbook
		XSSFWorkbook wBook = new XSSFWorkbook(fis);
		
		// Go to the sheet
		XSSFSheet sheet = wBook.getSheetAt(0);

		// This return no of row in excel sheet
		int rowCount = sheet.getLastRowNum();

		// Iterate it and print
		for (int i = 1; i <= rowCount; i++) {
		
			// Go to row
			XSSFRow row = sheet.getRow(i);
			
			// Go to cell
			XSSFCell cell = row.getCell(0);
			
			// Go to cell and read
			System.out.println("user name :: " + cell.getStringCellValue());
			System.out.println("password :: " + row.getCell(1).getStringCellValue());
		}

	}
	
	

}

package week5.day2;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class RunInGrid {

	public static void main(String[] args) throws WebDriverException, IOException {
		RemoteWebDriver driver;
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setBrowserName("firefox");
		dc.setPlatform(Platform.MAC);
		driver = new RemoteWebDriver(new URL("http://192.168.1.134:4444/wd/hub"),dc);
		
		// Set the system properties
		//System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");

		// Launch Browser - Google Chrome
		//ChromeDriver driver = new ChromeDriver();
		driver.get("http://jqueryui.com/draggable/");
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to URL
		//driver.get("http://jqueryui.com/draggable/");
		
		driver.switchTo().frame(driver.findElementByClassName("demo-frame"));
		
		WebElement draggable = driver.findElement(By.id("draggable"));
		System.out.println(draggable.getLocation());
		
		Actions builder = new Actions(driver);
		
		builder.dragAndDropBy(draggable, 100, 100)
		.build().perform();
		
		System.out.println(draggable.getLocation());
		
		FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./snaps/drag.jpeg"));
		
		
		
		
		
		
		
		
		
		

	}

}

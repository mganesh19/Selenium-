package k2b;

import karimbusiness.KarimsRules;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class K2BRules extends KarimsRules{

	
	
	@BeforeTest(groups={"dinein","delivery"})
	public void openANdSignin() {
		System.out.println(" OPens and Punches in");

	}
	
	@AfterTest(groups={"dinein","delivery"})
	public void siginOutAndClose() {
		System.out.println(" punches out and closes");
	}
	
	
}

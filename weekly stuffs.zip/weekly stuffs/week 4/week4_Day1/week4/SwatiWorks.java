package week4;

public class SwatiWorks {

	public static void main(String[] args) {

		SwatiLifeCycle swati = new SwatiLifeCycle();
		
		swati.wakeupAndMakeup();
		swati.openANdSignin();
		swati.changeToStoreAttire();

		swati.takeAndBillOrder();
		swati.cookAndServe();
		swati.cleanTheTable();
		
		swati.takeAndBillOrder();
		swati.cookAndServe();
		swati.cleanTheTable();
		
		swati.takeAndBillOrder();
		swati.cookAndServe();
		swati.cleanTheTable();
		
		
		
		
		
		
		
		
		
		
		
//		swati.
		
	}

}
